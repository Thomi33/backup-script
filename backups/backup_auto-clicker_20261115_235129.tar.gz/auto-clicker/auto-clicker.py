

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import threading
import time
from typing import Optional

from evdev import InputDevice, UInput, ecodes, list_devices

MIN_CPS = 1.0
MAX_CPS = 100.0
CPS_STEP = 5.0
DEFAULT_DEVICE_NAME = "SONiX Draconic"

BUTTONS = {
    "left": (ecodes.BTN_LEFT, "0xC0"),
    "right": (ecodes.BTN_RIGHT, "0xC1"),
    "middle": (ecodes.BTN_MIDDLE, "0xC2"),
}

state_lock = threading.Lock()
state_changed = threading.Event()
stop_event = threading.Event()
state = {"active": False, "cps": 10.0}


def format_cps(value: float) -> str:
    return f"{value:g}"


def prompt_cps(default: float = 10.0) -> float:
    while True:
        try:
            raw = input(f"CPS deseados ({MIN_CPS:g}-{MAX_CPS:g}) [{format_cps(default)}]: ").strip()
        except EOFError:
            return default
        if not raw:
            return default
        try:
            value = float(raw.replace(",", "."))
        except ValueError:
            print("Introducí un número, por ejemplo 12 o 25.")
            continue
        if MIN_CPS <= value <= MAX_CPS:
            return value
        print(f"El CPS debe estar entre {MIN_CPS:g} y {MAX_CPS:g}.")


def prompt_button(default: str = "left") -> str:
    while True:
        try:
            raw = input(f"Botón (left/right/middle) [{default}]: ").strip().lower()
        except EOFError:
            return default
        if not raw:
            return default
        if raw in BUTTONS:
            return raw
        print("Elegí left, right o middle.")


def choose_keyboard(explicit_path: Optional[str]) -> InputDevice:
    if explicit_path:
        dev = InputDevice(explicit_path)
        if ecodes.KEY_F5 not in dev.capabilities().get(ecodes.EV_KEY, []):
            dev.close()
            raise RuntimeError(f"{explicit_path} no anuncia soporte para KEY_F5.")
        return dev

    candidates = []
    for path in list_devices():
        try:
            dev = InputDevice(path)
            key_codes = dev.capabilities().get(ecodes.EV_KEY, [])
            if ecodes.KEY_F5 not in key_codes:
                dev.close()
                continue
            candidates.append(dev)
        except OSError:
            continue

    # En este equipo, el SONiX Draconic sin el sufijo "Keyboard" es el que
    # efectivamente reportó KEY_F5. Priorizamos ese dispositivo conocido.
    for dev in candidates:
        if dev.name == DEFAULT_DEVICE_NAME:
            for other in candidates:
                if other is not dev:
                    other.close()
            return dev

    for dev in candidates:
        if "keyboard" in dev.name.lower():
            for other in candidates:
                if other is not dev:
                    other.close()
            return dev

    for dev in candidates:
        dev.close()
    raise RuntimeError(
        "No encontré automáticamente un teclado que anuncie F5. "
        "Listá los dispositivos con `python -m evdev.evtest` y usá --device /dev/input/eventN."
    )


class ClickOutput:
    """Mantiene un dispositivo virtual abierto para evitar crear un proceso por clic."""

    def __init__(self, button: str):
        self.button = button
        self.button_code, self.ydotool_code = BUTTONS[button]
        self.ui: Optional[UInput] = None
        self.mode = ""

        try:
            self.ui = UInput(
                events={ecodes.EV_KEY: [self.button_code]},
                name="Python Auto Clicker",
            )
            self.mode = "uinput"
        except (OSError, PermissionError) as exc:
            if not shutil.which("ydotool"):
                raise RuntimeError(
                    f"No se pudo abrir /dev/uinput ({exc}) y no se encontró ydotool."
                ) from exc
            self.mode = "ydotool"
            print(
                f"Aviso: no pude abrir /dev/uinput ({exc}). Uso ydotool como alternativa; "
                "los CPS altos pueden ser menos precisos.",
                flush=True,
            )

    def click(self) -> None:
        if self.ui is not None:
            self.ui.write(ecodes.EV_KEY, self.button_code, 1)
            self.ui.syn()
            self.ui.write(ecodes.EV_KEY, self.button_code, 0)
            self.ui.syn()
            return

        # Alternativa compatible con la configuración actual de ydotool.
        result = subprocess.run(
            ["ydotool", "click", "--next-delay", "0", self.ydotool_code],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
            timeout=2,
            check=False,
        )
        if result.returncode != 0:
            detail = (result.stderr or "").strip()
            raise RuntimeError(detail or f"ydotool terminó con código {result.returncode}.")

    def close(self) -> None:
        if self.ui is not None:
            self.ui.close()
            self.ui = None


def set_active(active: bool) -> None:
    with state_lock:
        state["active"] = active
        cps = state["cps"]
    print(f"Autoclicker: {'ON' if active else 'OFF'} | {format_cps(cps)} CPS", flush=True)
    state_changed.set()


def change_cps(delta: float) -> None:
    with state_lock:
        state["cps"] = max(MIN_CPS, min(MAX_CPS, state["cps"] + delta))
        cps = state["cps"]
        active = state["active"]
    print(
        f"Velocidad: {format_cps(cps)} CPS | {'ON' if active else 'OFF'}",
        flush=True,
    )
    state_changed.set()


def click_worker(output: ClickOutput) -> None:
    while not stop_event.is_set():
        with state_lock:
            active = state["active"]
            cps = state["cps"]

        if not active:
            state_changed.wait(timeout=0.2)
            state_changed.clear()
            continue

        started = time.monotonic()
        try:
            output.click()
        except Exception as exc:
            with state_lock:
                state["active"] = False
            print(f"\nError al generar el clic: {exc}\nAutoclicker: OFF", flush=True)
            state_changed.set()
            continue

        # Ritmo basado en reloj monotónico; descuenta el tiempo que tardó el clic.
        deadline = started + (1.0 / cps)
        while not stop_event.is_set():
            with state_lock:
                still_active = state["active"]
            if not still_active:
                break
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            state_changed.wait(timeout=min(remaining, 0.05))
            state_changed.clear()


def keyboard_listener(dev: InputDevice) -> None:
    print(f"Teclado: {dev.path} | {dev.name}", flush=True)
    print("F5 = activar/desactivar | F6 = +5 CPS | F7 = -5 CPS | ESC = salir", flush=True)
    print("Arranca desactivado. Ctrl+C también sirve para salir.\n", flush=True)

    try:
        for event in dev.read_loop():
            if stop_event.is_set():
                break
            # Solo reaccionar al flanco de bajada evita repetir al mantener una tecla.
            if event.type != ecodes.EV_KEY or event.value != 1:
                continue
            if event.code == ecodes.KEY_F5:
                with state_lock:
                    next_active = not state["active"]
                set_active(next_active)
            elif event.code == ecodes.KEY_F6:
                change_cps(CPS_STEP)
            elif event.code == ecodes.KEY_F7:
                change_cps(-CPS_STEP)
            #elif event.code == ecodes.KEY_ESC:
                print("\nSaliendo...", flush=True)
                stop_event.set()
                state_changed.set()
                break
    except OSError as exc:
        if not stop_event.is_set():
            print(f"Error leyendo el teclado: {exc}", file=sys.stderr, flush=True)
    finally:
        stop_event.set()
        state_changed.set()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Autoclicker Linux: ajustá CPS y controlalo con F5/F6/F7."
    )
    parser.add_argument("--cps", type=float, help="Clics por segundo (1-100). Si se omite, pregunta al iniciar.")
    parser.add_argument("--button", choices=tuple(BUTTONS), help="Botón del mouse: left, right o middle.")
    parser.add_argument("--device", help="Dispositivo de teclado, por ejemplo /dev/input/event2.")
    args = parser.parse_args()
    if args.cps is not None and not (MIN_CPS <= args.cps <= MAX_CPS):
        parser.error(f"--cps debe estar entre {MIN_CPS:g} y {MAX_CPS:g}")
    return args


def main() -> int:
    args = parse_args()
    cps = args.cps if args.cps is not None else prompt_cps()
    button = args.button if args.button is not None else prompt_button()

    try:
        keyboard = choose_keyboard(args.device)
    except (OSError, RuntimeError) as exc:
        print(f"Error con el teclado: {exc}", file=sys.stderr)
        return 1

    try:
        output = ClickOutput(button)
    except (OSError, RuntimeError) as exc:
        keyboard.close()
        print(f"No pude preparar la salida de clics: {exc}", file=sys.stderr)
        return 1

    with state_lock:
        state["cps"] = cps

    print(f"Configuración: {format_cps(cps)} CPS | botón {button} | salida {output.mode}", flush=True)
    worker = threading.Thread(target=click_worker, args=(output,), daemon=True)
    worker.start()

    try:
        keyboard_listener(keyboard)
    except KeyboardInterrupt:
        print("\nInterrumpido; apagando autoclicker...", flush=True)
    finally:
        stop_event.set()
        state_changed.set()
        with state_lock:
            state["active"] = False
        worker.join(timeout=1.0)
        keyboard.close()
        output.close()
        print("Autoclicker cerrado.", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
