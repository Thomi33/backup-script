from evdev import InputDevice, ecodes

dev = InputDevice("/dev/input/event2")

for event in dev.read_loop():
    if event.type == ecodes.EV_KEY and event.code == ecodes.KEY_F6 and event.value == 1:
        print("F6!")